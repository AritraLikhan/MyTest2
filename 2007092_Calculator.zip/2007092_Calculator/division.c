#include "calculator.h"
float division(int num1 , int num2)
{
    float result;
    result =(float) num1 / num2 ;
    return result;
}