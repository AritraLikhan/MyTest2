int addition(int num1, int num2);
int subtraction(int num1, int num2);
int multiplication(int num1,int num2);
float division(int num1, int num2);