#include <stdio.h>
#include<stdlib.h>
#include "calculator.h"
int main()
{
    int num1,num2,res;
    char op;
    float div;
    printf("num1=");
    scanf("%d",&num1);
    printf("num2=");
    scanf("%d",&num2);
    printf("Enter a symbol for its operation:\n");
    printf("Addition: + \nSubtraction: - \nMultiplication: * \nDivision: \\ \n");
    scanf("\n%c",&op);
    switch(op)
    {
        case '+' :
        res=addition(num1,num2);
        printf("%d + %d = %d",num1,num2,res);
        break;

        case '-':
        res=subtraction(num1,num2);
        printf("%d - %d = %d",num1,num2,res);
        break;

        case '*' :
        res=multiplication(num1,num2);
        printf("%d * %d = %d",num1,num2,res);
        break;

        case '/' :
        div=division(num1,num2);
        printf("%d / %d = %f",num1,num2,div);
        break;
    }
    return 0;
}