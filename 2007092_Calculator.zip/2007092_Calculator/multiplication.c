#include "calculator.h"
int multiplication(int num1,int num2)
{
    int result;
    result = num1*num2;
    return result;
}